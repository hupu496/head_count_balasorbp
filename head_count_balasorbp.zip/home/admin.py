from django.contrib import admin
from home.models import MonitorData, MachineMast, CompanyMast, DepartMast, DesMast, EmpMast, EnrollMast


admin.site.register(EnrollMast)
admin.site.register(EmpMast)
admin.site.register(DepartMast)
# Register your models here.

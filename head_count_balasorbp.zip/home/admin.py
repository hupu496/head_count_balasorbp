from django.contrib import admin
from home.models import MonitorData, MachineMast, CompanyMast, DepartMast, DesMast, EmpMast, EnrollMast


admin.site.register(EnrollMast)
admin.site.register(EmpMast)
# Register your models here.

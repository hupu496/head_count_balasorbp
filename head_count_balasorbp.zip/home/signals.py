from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from home.models import ReportLog, MonitorData, MachineMast, CompanyMast, DepartMast, DesMast, EmpMast, EnrollMast, GatePass

@receiver(post_save, sender=ReportLog)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=ReportLog)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')
@receiver(post_save, sender=CompanyMast)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=CompanyMast)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')
@receiver(post_save, sender=MachineMast)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=MachineMast)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')


@receiver(post_save, sender=DepartMast)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=DepartMast)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')

@receiver(post_save, sender=DesMast)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=DesMast)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')

@receiver(post_save, sender=EmpMast)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=EmpMast)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')

@receiver(post_save, sender=EnrollMast)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=EnrollMast)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')

@receiver(post_save, sender=GatePass)
def save_to_mirror(sender, instance, **kwargs):
    instance.save(using='mirror')

@receiver(post_delete, sender=GatePass)
def delete_from_mirror(sender, instance, **kwargs):
    instance.delete(using='mirror')